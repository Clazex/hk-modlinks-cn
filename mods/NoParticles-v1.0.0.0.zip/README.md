# [No Particles](https://github.com/Clazex/HollowKnight.NoParticles)

A Hollow Knight mod that disables most of the particle effects.

Compatible with `Hollow Knight` 1.5.

## Contributing

1. Clone the repository
2. Set environment variable `HKRefs` to your `Managed` folder in HK installation
