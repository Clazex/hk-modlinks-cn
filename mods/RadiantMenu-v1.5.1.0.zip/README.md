# RadiantMenu

This is a mod for the game Hollow Knight.
It adds a new menu theme, which lies unused in the game files.
