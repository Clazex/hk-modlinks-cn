# ItemChanger

This is a Hollow Knight mod intended to be used by other mods for the purpose of changing or adding items, locations, transitions, starts, and other aspects of the world.

Documentation for most essential classes can be found here: https://homothetyhk.github.io/HollowKnight.ItemChanger/api/ItemChanger.html

ItemChanger is licensed under LGPL.