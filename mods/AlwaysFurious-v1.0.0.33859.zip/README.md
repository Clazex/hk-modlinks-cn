﻿# AlwaysFurious

A Hollow Knight mod that makes Fury of the Fallen always active.

Requires:
* SFCore
