# Introduction
AbsoluteZote is a mod boss for the game Hollow Knight aiming at creating a greater version of Grey Prince Zote.

# Hotkeys
F2: Teleport to AbsoluteZote.