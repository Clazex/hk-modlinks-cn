﻿# GPZ_Precepts

A Hollow Knight mod that makes GPZ display a random precept each time he takes damage. He is invulnerable while  it is displayed.

Requires:
* SFCore
