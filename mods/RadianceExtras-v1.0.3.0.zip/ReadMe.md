A Mod That adds Extra things to the Abs Radiance Fight.
Credit to RedFrog#8851 for helping

