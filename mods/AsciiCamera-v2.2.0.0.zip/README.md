# AsciiCamera

Applies a shader to the camera which makes the game output as ascii characters.

![Preview Image](img.jpg)
