# HollowKnight.CompassAlwaysOn

Mod that makes it so that the Knight icon is always shown on the map (as if the player had Wayward Compass), even if the compass isn't owned. Doesn't affect the save data in any way.

Note: if the mod doesn't work, chances are there's another mod that's conflicting with it. If so, please report which mods are installed, so we can fix the issue.

Note: if you are in a room (e.g. a shop, mound or black egg temple) when opening the save, the Knight icon won't appear until you leave the room (i.e. leave a doorway in the overworld). This is vanilla behaviour.
