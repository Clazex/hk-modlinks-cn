# ModConsole

This mod creates an in-game REPL which can be used to run dynamic C# at runtime to test mods and make debugging easier.

Can be toggled in-game using F9.

Font can be customized using settings file in saves directory.

Video: https://youtu.be/NiZFeKJj7R4

![demo](https://i.imgur.com/eh85mx0.png)

