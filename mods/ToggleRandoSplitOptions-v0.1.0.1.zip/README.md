# Toggle-Rando-Split-Options
An extension to the mod Toggleable bindings by [Unordinal](https://github.com/Unordinal). This mod adds split claw, split cloak and cursed nail to the binding list. To use, select the part of cloak/claw/nail you dont want and click apply. Currently there's binding for LeftNail, RightNail, Upslash, Pogo, LeftDash, RightDash, LeftClaw and RightClaw

## How to use
- [Download Toggleable Bindings](https://github.com/Unordinal/HollowKnight.ToggleableBindings) from the modinstaller.
- [Download this mod](https://github.com/TheMulhima/Toggle-Rando-Split-Options/releases/latest) and place it in the mods folder.
- Open the toggleable binding menu ingame and bind what skill you don't want to use.
<br /><br />[Toggleable Bindings Readme](https://github.com/Unordinal/HollowKnight.ToggleableBindings/blob/master/README.md)

## Credits
Thank you to ygsbzr for porting to 1.5
