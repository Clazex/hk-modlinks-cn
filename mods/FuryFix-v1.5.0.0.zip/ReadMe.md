# FuryFix

This is a mod for the game Hollow Knight

## Heads up

Things might be funky
