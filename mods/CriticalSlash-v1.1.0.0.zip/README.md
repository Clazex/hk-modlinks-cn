# CriticalSlash

Hollow Knight mod that makes all three nail arts deal extra damage and recover control quicker if they are released at the earliest moment.
This rewards the player for  choosing when to start charging narts so that they are able to land within this window,
which is a lot harder to do than I thought it would be.

Depends on [Satchel](https://github.com/PrashantMohta/Satchel). 
Time window, damage increase and recovery speed increase can all be configured in the mod menu settings.
Audiovisual feedback for performing a Critical Slash is currently provided by playing the Carefree Melody animation.