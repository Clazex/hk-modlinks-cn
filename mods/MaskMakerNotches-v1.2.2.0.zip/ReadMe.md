# MaskMakerNotches

A mod that adds a few buyable Charm Notches near Mask Maker. Intended for use with mods that add charms to better allow us to use the new things they add, and also Randomizer.
