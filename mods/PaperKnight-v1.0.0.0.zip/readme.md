# PaperKnight Mod

This mod is purely cosmetic. When a sprite turns to face in a different direction, it will now rotate as if it's made of paper. The knight, as well as enemies struck by the knight's nail, will spin rapidly with this paper effect as well. The effect is designed to look like the Paper Mario spin effect.