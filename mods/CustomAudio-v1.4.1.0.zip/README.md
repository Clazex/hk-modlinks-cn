# CustomAudio
A Hollow Knight mod can replace some kind of audio
## How to use it
1. Install the mod
2. run once game.
3. prepare `.wav` audio file
4. put audio file in `ReplaceAudio`folder where CustomAudio mod in
5. rename audio as orignal audio name(like `Salubra_Shop_Greet.wav`)
6. restart game
## About CustomKnight
if you install CustomKnight mod,you can put your audio in `Skins/<skinname>/Audio`,then the mod will use audio in this folder