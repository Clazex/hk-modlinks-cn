# HollowKnight.InvincibilityMonitor

Mod that gives the knight invincibility in the following situations (each can be toggled separately in the global settings):
- While at a bench
- While watching a cutscene (e.g. Hornet in the City of Tears)
- While focusing THK
- While collecting an item
- While talking, shopping or selecting a stag station
- While stunned by a boss scream
- While waking up
- While leaving a transition
- While riding a small elevator
- While close to the lever in a large elevator

After these conditions stop being true, you get a small window (0.2s by default, but toggleable in the global settings) before losing invincibility.
