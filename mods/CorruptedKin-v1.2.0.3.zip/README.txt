 ▄████▄   ▒█████   ██▀███   ██▀███   █    ██  ██▓███  ▄▄▄█████▓▓█████ ▓█████▄ 
▒██▀ ▀█  ▒██▒  ██▒▓██ ▒ ██▒▓██ ▒ ██▒ ██  ▓██▒▓██░  ██▒▓  ██▒ ▓▒▓█   ▀ ▒██▀ ██▌
▒▓█    ▄ ▒██░  ██▒▓██ ░▄█ ▒▓██ ░▄█ ▒▓██  ▒██░▓██░ ██▓▒▒ ▓██░ ▒░▒███   ░██   █▌
▒▓▓▄ ▄██▒▒██   ██░▒██▀▀█▄  ▒██▀▀█▄  ▓▓█  ░██░▒██▄█▓▒ ▒░ ▓██▓ ░ ▒▓█  ▄ ░▓█▄   ▌
▒ ▓███▀ ░░ ████▓▒░░██▓ ▒██▒░██▓ ▒██▒▒▒█████▓ ▒██▒ ░  ░  ▒██▒ ░ ░▒████▒░▒████▓ 
░ ░▒ ▒  ░░ ▒░▒░▒░ ░ ▒▓ ░▒▓░░ ▒▓ ░▒▓░░▒▓▒ ▒ ▒ ▒▓▒░ ░  ░  ▒ ░░   ░░ ▒░ ░ ▒▒▓  ▒ 
  ░  ▒     ░ ▒ ▒░   ░▒ ░ ▒░  ░▒ ░ ▒░░░▒░ ░ ░ ░▒ ░         ░     ░ ░  ░ ░ ▒  ▒ 
░        ░ ░ ░ ▒    ░░   ░   ░░   ░  ░░░ ░ ░ ░░         ░         ░    ░ ░  ░ 
░ ░          ░ ░     ░        ░        ░                          ░  ░   ░    
░                                                                      ░      
                            ██ ▄█▀ ██▓ ███▄    █                              
                            ██▄█▒ ▓██▒ ██ ▀█   █                              
                           ▓███▄░ ▒██▒▓██  ▀█ ██▒                             
                           ▓██ █▄ ░██░▓██▒  ▐▌██▒                             
                           ▒██▒ █▄░██░▒██░   ▓██░                             
                           ▒ ▒▒ ▓▒░▓  ░ ▒░   ▒ ▒                              
                           ░ ░▒ ▒░ ▒ ░░ ░░   ░ ▒░                             
                           ░ ░░ ░  ▒ ░   ░   ░ ░                              
                           ░  ░    ░           ░                              
                                                                              
by Nickc01

--[About]------------------------------------------------

Corrupted Kin is a mod that takes the Lost Kin bossfight and completely reimagines it

It adds an all new second phase to the fight that utilizes a custom built wave system, as well as many other new moves

He can be fought in godhome, or in the abyss dream arena by checking the "Enable In Abyss" option in the Weaver Mod Settings Menu

--[Requirements]-----------------------------------------

Requires Modding API to be installed

Requires WeaverCore v1.0.0.0 or newer to be installed



Video of Mod in Action : https://youtu.be/8vQiSoLYrao
Github Page for more info : https://github.com/nickc01/Corrupted-Kin
