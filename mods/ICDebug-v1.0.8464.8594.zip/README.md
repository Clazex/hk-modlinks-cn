﻿# ICDebug

A Hollow Knight mod that adds ItemChanger debugging commands to ModTerminal
