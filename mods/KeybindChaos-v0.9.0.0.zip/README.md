# HollowKnight.KeybindChaos

Mod that can randomize the keybinds at regular intervals. Currently supports the 8 main hero actions 
(jump, attack, dash, focus, superdash, dream nail, quick cast, quick map) - movement keys are unaffected.

Several configuration options are available in the mod menu. Further options (such as disabling certain keybinds from randomization)
are available in the global settings file.
