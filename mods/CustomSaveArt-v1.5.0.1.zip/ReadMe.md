# CustomSaveArt

This is a mod for the game Hollow Knight

## Heads up

Right now it replaces White Palace Save Art to a custom made one
