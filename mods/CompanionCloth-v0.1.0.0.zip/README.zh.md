# [伙伴阿布](https://github.com/Clazex/HollowKnight.CompanionCloth)

一个可以让阿布全程陪同并助战的《空洞骑士》模组

适用于 `空洞骑士` 1.5。
**需要 `Vasi`。**

## 功能
这个模组可以让你按一个键来召唤（以及取消召唤）阿布。
阿布可以像在叛徒领主 Boss 战中一样与你战斗。
还可以让你按另一个键将阿布传送回身边。

## 配置
- `SummonKey` (`String`)：召唤/取消召唤阿布的按键。默认为 `y`。
- `RecallKey` (`String`)：召回阿布的按键。默认为 `u`。

## 贡献

1. 克隆存储库
2. 将环境变量 `HKRefs` 设置为游戏文件中的 `Managed` 文件夹
