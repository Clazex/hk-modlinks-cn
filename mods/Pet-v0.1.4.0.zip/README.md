﻿# Pet

A mod for the game Hollow Knight.

Gives pets that follow the hero.

* Shade - A small pet, usually given to new players to keep them company, and maybe one or two other things ...


## How to use

* Install from Scarab. Works with Hollow Knight 1.5.
* Turn on/off in Mods menu.


## Have a question or report a bug?

Join discord server: https://discord.gg/vqKTF26VGX
