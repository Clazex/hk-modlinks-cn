# FallDamage

A mod for the game Hollow Knight (v1.5.x).

The player now takes damage proportional to their maximum base health and the time spent falling. Does *not* function on inventory drops.

Comes with Options menu to enable and disable the mod + two modes: **REGULAR** and **GLASS ANKLES**
