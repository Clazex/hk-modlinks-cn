# Aspid Queen

Mod portion of Aspid Queen.
