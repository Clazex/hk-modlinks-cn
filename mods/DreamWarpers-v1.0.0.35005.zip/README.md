﻿# DreamWarpers

A Hollow Knight mod that makes Gorb, Elder Hu, and No Eyes teleport 100% of the time after being damaged.

Requires:
* SFCore
