# GeoLog

This is a mod for the game Hollow Knight

## Heads up

Insane first loading time, checks for every source of geo and prints it in the modlog
