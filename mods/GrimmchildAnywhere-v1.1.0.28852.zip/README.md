﻿# GrimmchildAnywhere

A Hollow Knight mod that allows Grimmchild to spawn during TMG and NKG fights.

Requires:
* SFCore
