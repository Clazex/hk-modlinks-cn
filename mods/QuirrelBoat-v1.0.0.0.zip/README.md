# QuirrelBoat

A small meme mod for Hollow Knight. Changes some things with Quirrel at Blue Lake.

Thanks to Failed Vessel for the sprite.
