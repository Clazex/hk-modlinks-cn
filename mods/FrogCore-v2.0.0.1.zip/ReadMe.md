# FrogCore

A library of useful classes or Helpers that I make or stuff that doesn't belong anywhere but still may be of use to some people