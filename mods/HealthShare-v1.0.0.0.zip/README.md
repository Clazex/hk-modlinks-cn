# [Health Share](https://github.com/Clazex/HollowKnight.HealthShare)

[![Commitizen friendly](https://img.shields.io/badge/commitizen-friendly-brightgreen.svg)](http://commitizen.github.io/cz-cli/)

A Hollow Knight mod to let some bosses use shared health.

Compatible with `Hollow Knight` 1.5.

Bosses affected includes Vengefly King, Brothers Oro & Mato, Mantis Lords, Sisters of Battle and God Tamer. Default disabled.
