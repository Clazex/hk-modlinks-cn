# BetterDreamShieldCoop

Remake of my old remake of the dreamshield coop mod, but there's an api for easily adding other types of coop (ex: grimchild)

This mod allows another player to control a coop "mode" by setting keybinds for that mode in the options menu.

Currently Added modes:
 - Dreamshield:
   - Can fly around without collision
   - Makes the player bounce upwards if hit
   - Can rotate (Idk why you would want to do this, idk why I added it in my original remake)
   - NEW: Can stick to the player like the original dreamshield and rotate around using the rotation controls and the up and down controls to go farther away
 - Grimmchild:
   - Can fly around without collision
   - Force shoot button for rapid fire
   - NEW: Force stop shooting mode
   - REMOVED: Can no longer rotate (Why did I do this.......)
   - NEW: Similarly to the dreamshield, can stick to the player like the normal grimmchild. You will only be able to force shoot and force stop shooting in this mode.

Custom Knight Compatibility!

Both the Dreamshield and Grimmchild have their own separate sprite collections! (AKA, different spritesheet name for customknight)
They use Shield_coop.png and Grimm_coop.png, if these are not present, they will retain their default sprites.