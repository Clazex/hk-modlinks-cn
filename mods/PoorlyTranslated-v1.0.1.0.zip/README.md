# HollowKnight.TranslationMod
Poorly Translated Hollow Knight. All text in the game is run through a chain of google translates.

Translations are available in English, German, Spanish, French, Italian and Chinese

Originally made by [Gradow](https://github.com/ricardosouzag) and Avenging Angle


