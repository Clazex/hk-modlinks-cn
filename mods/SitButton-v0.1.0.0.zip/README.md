﻿# SitButton

A Hollow Knight mod that adds a button to sit
