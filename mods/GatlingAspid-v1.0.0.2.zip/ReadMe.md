# Gatling Aspid

A mod that makes primal aspids wield miniguns with various customization options.

To turn on crystal projectiles, open up the Gatling Aspid global settings file `GatlingAspid.GlobalSettings.json` in the Hollow Knight saves directory and change `Crystals` to `true`.

To turn on grenades, set `Grenades` to `true`.

`ShotsPerBarrage` defines how many bullets are fired at a time.

`FireRate` defines how many bullets are fired per second.

Aspid minigun sprites made by MEBI:
https://twitter.com/MEBI96862134?s=20&t=mwJdVbJebdWXepH-QVzIvw
