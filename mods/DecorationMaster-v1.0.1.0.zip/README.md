# HollowKnight.Decoration
A mod can place items in-game.


##usage

**Press CapsLock to enable item place**

**To Share your Decoration to friends, you can copy your ***Mods\DecorationMasterData** folder which are auto save in your mod dir**

**If you want to remove some item, you can us ***Attack*** this item(make sure you is in editing status)**

**Attention!!**
the keys are changing now
current Operation:
Tab to switch group
key 1-6 select item or use Pickup UI above the screen
middle mouse key toggle attribute inspector
left mouse key place item
right mouse key discard current selected item
Space key to set prefab
Ctrl+C for copy multi objects
Ctrl+Z for undo adding last
**Attention2!!**
now(version0.4) move some advance items to professor mode, these items require some knowledge,so do not use 
unless you understand what it is!
this is the following:
- Hazard Respawn Remover : to remove original game's respawn trigger
- Scene Remove : to remove the WHOLE things in the room except custom items

**FAQ**
Q:what does the chinese characters while game start showing mean?
A:it genally about that you can't sell you level or packge levels on other commodities. Because I notice that someone sell their hollow knight skins, I Object to this.

###TODO:
make ui more friendly