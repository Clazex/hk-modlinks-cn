# Hell Mod

A tiny mod I made a long time ago. Nerfs your damage, soul, and healing while increasing incoming damage. Configurable via a settings file.
