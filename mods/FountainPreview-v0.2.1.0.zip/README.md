# HollowKnight.FountainPreview

Add-on for ItemChanger that makes the basin vessel fragment location show a visual preview of its item to replace the vanilla vessel fragment object.
