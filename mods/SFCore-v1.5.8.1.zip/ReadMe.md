# SFCore

This is a library for mods aiming to add custom achievements, items and charms to the game.
