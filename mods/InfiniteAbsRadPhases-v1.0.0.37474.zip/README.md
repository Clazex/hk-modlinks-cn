﻿# InfiniteAbsRadPhases

A Hollow Knight mod that makes a selected Absolute Radiance Phase infinite (5 does nothing).

Requires:
* SFCore
* Satchel
