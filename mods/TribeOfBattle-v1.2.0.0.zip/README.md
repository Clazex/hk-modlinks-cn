# [Tribe of Battle](https://github.com/Clazex/HollowKnight.TribeOfBattle)

[![Commitizen friendly](https://img.shields.io/badge/commitizen-friendly-brightgreen.svg)](http://commitizen.github.io/cz-cli/)

A Hollow Knight mod boss based on Sisters of Battle and Traitor Lord.
Recreation of the old version by [jngo102](https://github.com/jngo102) which is for 1.4 version of the game.

Compatible with `Hollow Knight` 1.5.
