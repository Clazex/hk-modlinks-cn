# [战斗部落](https://github.com/Clazex/HollowKnight.TribeOfBattle)

[![Commitizen 友好](https://img.shields.io/badge/commitizen-友好-brightgreen.svg)](http://commitizen.github.io/cz-cli/)

一个基于战斗姐妹和叛徒领主的《空洞骑士》Mod Boss。
[jngo102](https://github.com/jngo102) 的用于 1.4 版游戏的旧版的重制。

适用于 `空洞骑士` 1.5。
