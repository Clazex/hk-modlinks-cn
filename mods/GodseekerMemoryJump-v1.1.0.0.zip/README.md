# HollowKnight.GodseekerMemoryJump
Face right when dreamnailing the Godseeker Corpse to warp to the hidden memory rather than Godhome. 

Works even if you've visited the memory before, but does not work if you haven't visited Godhome yet.
