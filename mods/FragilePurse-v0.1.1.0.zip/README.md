﻿# FragilePurse

Made by [Mimijackz#3527](github.com/mimijackz)
Inspired by a suggestion from Ender Onryo#5273

Makes you drop geo whenever you get hit, and has a setting to kill you if you get hit without any geo
This is basically the opposite of TheCurseOfSly