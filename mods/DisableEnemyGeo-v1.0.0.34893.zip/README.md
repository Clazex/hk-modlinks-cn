﻿# DisableEnemyGeo

A Hollow Knight mod that makes enemies no longer drop Geo.

Requires:
* SFCore
