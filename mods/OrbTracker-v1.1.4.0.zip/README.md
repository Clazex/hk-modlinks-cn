# Orb Tracker
Hollow Knight mod that shows how many Whispering Root orbs are left to collect, and points an arrow to the nearest one.

Requires [Vasi](https://github.com/fifty-six/HollowKnight.Vasi/tree/master/Vasi).
