﻿# MashSlash

A mod for the game Hollow Knight (v1.5.x).

The player can now swing their nail without limitation. Slashes will come out as quickly as you can mash the button.

Comes with the option to require equipping the Quick Slash charm, in case being able to mash slash without cost is too overpowered.
