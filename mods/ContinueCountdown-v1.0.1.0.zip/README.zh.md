# [继续倒计时](https://github.com/Clazex/HollowKnight.ContinueCountdown)

[![Commitizen 友好](https://img.shields.io/badge/commitizen-友好-brightgreen.svg)](http://commitizen.github.io/cz-cli/)

一个在继续时添加一个倒计时的《空洞骑士》模组

适用于 `空洞骑士` 1.5。
