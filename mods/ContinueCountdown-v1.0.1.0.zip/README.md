# [Continue Countdown](https://github.com/Clazex/HollowKnight.ContinueCountdown)

[![Commitizen friendly](https://img.shields.io/badge/commitizen-friendly-brightgreen.svg)](http://commitizen.github.io/cz-cli/)

A Hollow Knight mod that adds a countdown upon continuing

Compatible with `Hollow Knight` 1.5.
