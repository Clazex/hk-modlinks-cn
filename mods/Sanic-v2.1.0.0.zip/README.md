# Sanic

Mod for Hollow Knight which allows you to change the default timescale as well 
as also affecting the rate of timescale changes to match the timescale itself.

Can be configured via a settings json (`Sanic.GlobalSettings.json`) located
within the Hollow Knight saves folder.