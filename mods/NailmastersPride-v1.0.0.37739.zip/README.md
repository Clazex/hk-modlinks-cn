﻿# NailmastersPride

A Hollow Knight mod that makes Nailmaster's Glory grant all Nail Arts, automatically charge Nail Arts, and prevent regular Nail attacks.
