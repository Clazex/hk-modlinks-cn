# Rando Vanilla Tracker
Connection mod for Hollow Knight Randomizer 4 that allows for tracking of vanilla placements.

This mod only works when starting a new randomizer save. Click on "Connections", then "RandoVanillaTracker", then select what you want to track.
