# Hall of Gods Extras

Adds The Hollow Knight and The Radiance as bosses to the Hall of Gods.
