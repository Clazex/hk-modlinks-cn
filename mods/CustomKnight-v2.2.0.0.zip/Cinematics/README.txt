Supported Cinematics : 

Prologue.webm
Intro.webm
StagTunnelRun.webm
CharmSlugKiss.webm
Nailsmith.webm
NailsmithPaint.webm
Blacksmith.webm
FinalA.webm
FinalB.webm
FinalC.webm
FinalD.webm
FinalE.webm
MrMushroom.webm
Telescope.webm
Fountain.webm
MaskShatter.webm

Required Format :

Video: 1080p, 30fps, VP8 encoding
Audio: 48000hz sample rate, 2 channels, Vorbis encoding
Container: WebM

FFMPEG command to get this Format:

ffmpeg -i <INFILE> -c:v libvpx -crf 10 -b:v 8M -c:a libvorbis -q 6 <OUTFILE>.webm

