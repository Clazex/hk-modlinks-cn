# SpriteDumper

This mod is for dumping sprites.  
The first dump process can take 10 minutes or more.  
Currently the button `P` is used to initiate a dumping process.
