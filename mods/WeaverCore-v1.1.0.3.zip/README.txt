██╗    ██╗███████╗ █████╗ ██╗   ██╗███████╗██████╗  ██████╗ ██████╗ ██████╗ ███████╗
██║    ██║██╔════╝██╔══██╗██║   ██║██╔════╝██╔══██╗██╔════╝██╔═══██╗██╔══██╗██╔════╝
██║ █╗ ██║█████╗  ███████║██║   ██║█████╗  ██████╔╝██║     ██║   ██║██████╔╝█████╗  
██║███╗██║██╔══╝  ██╔══██║╚██╗ ██╔╝██╔══╝  ██╔══██╗██║     ██║   ██║██╔══██╗██╔══╝  
╚███╔███╔╝███████╗██║  ██║ ╚████╔╝ ███████╗██║  ██║╚██████╗╚██████╔╝██║  ██║███████╗
 ╚══╝╚══╝ ╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝
                                                                                    
WeaverCore by Nickc01

--- : About : ------------------------------------------------------------------------

WeaverCore is a mod that is designed to make it easy to develop new content for the game, such as new Enemies, Bosses, Scenes, and more



This mod doesn't provide much functionality on its own, and is designed to be a dependency for other mods to work

The main addition this mod brings is a new settings menu that is accessable on the title screen and pause menu, which
provides an interface for WeaverCore dependent mods to be configured with

--- : Links : ------------------------------------------------------------------------

Github Page for more info : https://github.com/nickc01/WeaverCore