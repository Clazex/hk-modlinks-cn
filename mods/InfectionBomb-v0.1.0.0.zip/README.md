﻿# Infectionbomb

A Hollow Knight mod that spawns radiance whenever you kill an infected bug
