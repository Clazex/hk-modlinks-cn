# HollowKnight.CustomJournal
A CustomKnight Addon mod
## Usage
It's an addon mod,what you need to do is go to CustomJournal modmenu,set `Dump Enable` to `enable`,then use CK's Dumping Sprite ,then go to `Dump/Journal` to find image,then<br/>
* To replace a sprite : `Mods/Custom Knight/Skins/<skin>/Swap/Journal/<gameobjectname>.png` (will only update once change skin or enter save)
