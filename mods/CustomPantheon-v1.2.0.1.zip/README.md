# [CustomPantheon](https://github.com/ygsbzr/HollowKnight.CustomPantheon)
A mod add a extra boss door in God Home
Recreation of the old version by [RedFrog](https://github.com/RedFrog6002) which is for 1.4 version of the game.
Compatible with `Hollow Knight` 1.5.
## How to use it
1. Install the mod and run game once.
2. Find `CustomPantheon.GlobalSettings.json` in your save folder.
3. Edit `PantheonRooms` in this json as
```json
"PantheonRooms": [
    "GG_Ghost_Marmu",
    "GG_Sly"
  ]
```
(Write the scenename you want)You can use BenchWarp to see room name or use [SceneName.txt](SceneName.txt)

