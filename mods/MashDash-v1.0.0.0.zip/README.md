﻿# MashDash

A Hollow Knight mod that removes the limit on dashing
