﻿Companion mod to [HKAT](https://github.com/RanDumSocks/HKAutoTrackerElectron). Install this to use location tracking feature in that softwre. More information is also over at that repository.

This mod very simply logs your location to a `.json` file in the save data directory. It also has an in-game option to open the companion software.
