# FastTravel

Teleport anywhere within Hallownest by clicking on the map.
