       ██▓ ███▄    █   █████▒▓█████  ██▀███   ███▄    █  ▒█████             
      ▓██▒ ██ ▀█   █ ▓██   ▒ ▓█   ▀ ▓██ ▒ ██▒ ██ ▀█   █ ▒██▒  ██▒           
      ▒██▒▓██  ▀█ ██▒▒████ ░ ▒███   ▓██ ░▄█ ▒▓██  ▀█ ██▒▒██░  ██▒           
      ░██░▓██▒  ▐▌██▒░▓█▒  ░ ▒▓█  ▄ ▒██▀▀█▄  ▓██▒  ▐▌██▒▒██   ██░           
      ░██░▒██░   ▓██░░▒█░    ░▒████▒░██▓ ▒██▒▒██░   ▓██░░ ████▓▒░           
      ░▓  ░ ▒░   ▒ ▒  ▒ ░    ░░ ▒░ ░░ ▒▓ ░▒▓░░ ▒░   ▒ ▒ ░ ▒░▒░▒░            
       ▒ ░░ ░░   ░ ▒░ ░       ░ ░  ░  ░▒ ░ ▒░░ ░░   ░ ▒░  ░ ▒ ▒░            
       ▒ ░   ░   ░ ░  ░ ░       ░     ░░   ░    ░   ░ ░ ░ ░ ░ ▒             
       ░           ░            ░  ░   ░              ░     ░ ░             
                                                                            
 ██ ▄█▀ ██▓ ███▄    █   ▄████      ▄████  ██▀███   ██▓ ███▄ ▄███▓ ███▄ ▄███▓
 ██▄█▒ ▓██▒ ██ ▀█   █  ██▒ ▀█▒    ██▒ ▀█▒▓██ ▒ ██▒▓██▒▓██▒▀█▀ ██▒▓██▒▀█▀ ██▒
▓███▄░ ▒██▒▓██  ▀█ ██▒▒██░▄▄▄░   ▒██░▄▄▄░▓██ ░▄█ ▒▒██▒▓██    ▓██░▓██    ▓██░
▓██ █▄ ░██░▓██▒  ▐▌██▒░▓█  ██▓   ░▓█  ██▓▒██▀▀█▄  ░██░▒██    ▒██ ▒██    ▒██ 
▒██▒ █▄░██░▒██░   ▓██░░▒▓███▀▒   ░▒▓███▀▒░██▓ ▒██▒░██░▒██▒   ░██▒▒██▒   ░██▒
▒ ▒▒ ▓▒░▓  ░ ▒░   ▒ ▒  ░▒   ▒     ░▒   ▒ ░ ▒▓ ░▒▓░░▓  ░ ▒░   ░  ░░ ▒░   ░  ░
░ ░▒ ▒░ ▒ ░░ ░░   ░ ▒░  ░   ░      ░   ░   ░▒ ░ ▒░ ▒ ░░  ░      ░░  ░      ░
░ ░░ ░  ▒ ░   ░   ░ ░ ░ ░   ░    ░ ░   ░   ░░   ░  ▒ ░░      ░   ░      ░   
░  ░    ░           ░       ░          ░    ░      ░         ░          ░   
                                                                            
Inferno King Grimm by Nickc01

--- : About : ------------------------------------------------------------------------

Inferno King Grimm is a boss mod that takes the existing Nightmare King Grimm bossfight and changes it up significantly

The fight is split up into three different stages, with each stage getting harder than the last

It also includes several modifications to existing moves, as well as some new ones

There is also an optional hard mode that can be enabled using the settings menu found on the title screen

Hard mode includes harder versions of the existing moves, a health upgrade, and a new move exclusive to hard mode

--- : Installation : -----------------------------------------------------------------

WeaverCore is required for the mod to run properly. Be sure you have that installed as well

Once both mods are installed, you can then battle against Inferno King Grimm in Hall of Gods Arena

You can also battle against IKG in the Dirtmouth Arena if you have the Infinite Grimm Mod installed

--- : Links: -------------------------------------------------------------------------

Video of boss in action : https://youtu.be/R20mWJJOJ0w

Video of hard mode version : https://youtu.be/OhKrdlC6nNk

Github page for more info : https://github.com/nickc01/Inferno-King-Grimm