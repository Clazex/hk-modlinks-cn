# [Everwatchers](https://github.com/Clazex/HollowKnight.Everwatchers)

[![Commitizen friendly](https://img.shields.io/badge/commitizen-friendly-brightgreen.svg)](http://commitizen.github.io/cz-cli/)

A Hollow Knight mod boss based on Watcher Knights.

Compatible with `Hollow Knight` 1.5.
