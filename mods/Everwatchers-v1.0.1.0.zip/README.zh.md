# [永恒守望者](https://github.com/Clazex/HollowKnight.Everwatchers)

[![Commitizen 友好](https://img.shields.io/badge/commitizen-友好-brightgreen.svg)](http://commitizen.github.io/cz-cli/)

一个基于守望者骑士的《空洞骑士》Mod Boss.

适用于 `空洞骑士` 1.5。
