# [Double Jump Fix](https://github.com/Clazex/HollowKnight.DoubleJumpFix)

A Hollow Knight mod to fix the notorious bug that the double jump is sometimes not properly canceled.

Compatible with `Hollow Knight` 1.5.

## Contributing

1. Clone the repository
2. Set environment variable `HKRefs` to your `Managed` folder in HK installation
