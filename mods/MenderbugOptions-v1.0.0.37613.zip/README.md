﻿# MenderbugOptions

A Hollow Knight mod that lets you choose Menderbug's spawn chance, whether he respawns after dying, and whether the sign must be broken.

Requires:
* Satchel
