# TestOfTeamwork

This mod adds a platforming section to the White Palace.  
This plaforming section is called "Test of Teamwork".  

This mod is build quest-like, with it's start being a conversation with someone familiar in and around Dirtmouth.
