# ResetCharmNotches

This is a mod for the game Hollow Knight

## Heads up

This will break other mods that replace charms, e.g. Lightbringer.
