# ExtraMenuBackgrounds

Adds new main menu themes to the Extras menu, each derived from an in-game scene.
Depends on SFCore.

Currently featured menu backgrounds:
+ Crystal Peak
+ Queen's Gardens
+ Hive
+ City of Tears
+ Land of Storms
