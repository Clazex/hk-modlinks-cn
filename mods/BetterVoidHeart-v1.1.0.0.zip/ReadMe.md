# Better Void Heart

When you pick up Void Heart, you don't lose the soul regen from Kingsoul.

You can set the amount of soul regenerated in the mod menu. The default (Kingsoul) value is 4 soul; you can change it to 1, 2, 4, 7, or 11 soul.

Requires Satchel.
