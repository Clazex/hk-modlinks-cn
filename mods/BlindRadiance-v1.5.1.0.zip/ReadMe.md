# BlindRadiance

This mod makes the background of selected scenes black for better visibility of bright sprites (e.g. Radiance in the final boss fight).

These selected scenes are adjustable in this mod's global settings file.
