# [Godseeker +](https://github.com/Clazex/HollowKnight.GodSeekerPlus)

[![Commitizen friendly](https://img.shields.io/badge/commitizen-friendly-brightgreen.svg)](http://commitizen.github.io/cz-cli/)

A Hollow Knight mod to enhance your Godhome experience

Compatible with `Hollow Knight` 1.5.
**`Satchel` is required for in-game menu.**

## Features

- **Boss Challenge**:
  + **Activate Fury**: Activate Fury of the Fallen on entry of boss scenes by setting health to 1.
  + **Add Lifeblood**: Add configured amount of lifeblood on entry of Hall of Gods boss fight.
  + **Add Soul**: Add configured amount of soul on entry of Hall of Gods boss fight.
  + **Carefree Melody Reset**: Reset Carefree Melody hit counter to maximum when entering Godhome non-boss scenes.
  + **Force Arrive Animation**: Force the arrive animation to be played when fighting Vengefly King, Xero, Hive Knight and Enraged Guardian in Hall of Gods.
  + **Force Grey Prince Enter Type**: Force select enter type that Grey Prince use.
  + **Halve Damage (HoG Ascended or above)**: Halve all the damage taken when challenging at Ascended difficulty or above in Hall of Gods.
  + **Halve Damage (HoG Attuned)**: Halve all the damage taken when challenging at Attuned difficulty in Hall of Gods.
  + **Halve Damage (Other Place)**: Halve all the damage taken when not in Godhome boss scenes.
  + **Halve Damage (Pantheons)**: Halve all the damage taken when in pantheons.
  + **Infinite Grimm Pufferfish**: When fighting in the Hall of Gods, make Troupe Master Grimm and Nightmare King Grimm only do pufferfish attack.
  + **Infinite Radiance Climbing**: When fighting in the Hall of Gods, starts Absolute Radiance boss fight from the end of Phase 2 and reset when starting final phase.
  + **P5 Health**: Reduce boss health in Ascended and Radiant difficulty to match with Attuned difficulty.
  + **Segmented P5**: Add a pantheon entry to the left of the entrance of the Land of Storms, at which you can select a segment of the Pantheon of Hallownest to challenge.

- **Bugfix**:
  + **Camera Keep Rumbling**: Prevent camera from keeping rumbling after scene transitions in Godhome.
  + **Crossing Ooma**: Prevent Ooma from spawning explosive jellies across scenes.
  + **God Tamer Beast Roll Collider**: Prevent God Tamer's Beast's collider from not restoring after rolling.
  + **Grey Prince Nail Slam Collider**: Prevent Grey Prince's nail slam collider from not disappearing when staggered.
  + **Transition Death**: Prevent from continuing pantheon challenges after death upon scene transitions.

- **Cosmetic**:
  + **More Pantheon Caps**: Enable the unused no hit cap for Pantheons 1 to 4, and add a new special effect for all pantheons indicating completed once no hit with all bindings.
  + **No Fury Effect**: Remove the red effect around the screen when the Fury of Fallen is activated.
  + **No Low Health Effect**: Remove all low health related effects.

- **New Save Quickstart**:
  + **Unlock Eternal Ordeal**: Auto unlock the Eternal Ordeal.
  + **Unlock Pantheons**: Auto unlock Pantheon of Knight and the Pantheon of Hallownest when in Godseeker mode, also activates some objects in the Godhome Atrium Roof.
  + **Unlock Radiance**: Auto unlock the Radiance in Hall of Gods when in Godseeker mode.
  + **Unlock Radiant**: Auto unlock Radiant difficulty for all boss statues.

- **Quality of Life**:
  + **Complete Lower Difficulty**: Auto complete lower difficulties for boss statues if higher ones are completed. Triggers when opening challenge UI.
  + **Correct Radiance HP**: Correct Absolute Radiance's health value to make her die at zero health.
  + **Door Default Begin**: Default selecting the Begin button when opening Pantheon Door UI.
  + **Eternal Ordeal Platform**: Add a platform at the entrance of the Eternal Ordeal.
  + **Fast Dash**: Remove dash cooldown when in Hall of Gods.
  + **Fast Dream Warping**: Remove dream warping charge time when in boss scenes. This decrease the total warping time from 2.25s to 0.25s.
  + **Fast Super Dash**: Buff Super Dash speed in Hall of Gods.
  + **Grey Prince Toggle**: Add a Dream Nail toggle beside Grey Prince statue to show and control whether Grey Prince will appear in the Pantheons or not when in Godseeker mode.
  + **Memorize Bindings**: Memorize the Bindings selected last time, like difficulties in the Hall of Gods. Recommend using with Door Default Begin.
  + **P5 Teleport**: Allow using the Dream Nail towards the lever which is used to unlock Godhome Atrium Roof to teleport to beside the Pantheon of Hallownest.
  + **Short Death Animation**: Skip part of the death animation when in boss scenes.

- **Restrictions**:
  + **Create Lag**: Create a lag in every in-game frame.
  + **No Dive Invincibility**: Remove invincibility frames from Desolate Dive and Descending Dark.
  + **No Nail Attack**: Disable normal nail attack.
  + **No Nail Damage**: Remove damage from nail attacks, including nail arts.
  + **No Spell Damage**: Remove damage from spells, including Sharp Shadow.

- **Miscellaneous**
  + **Aggressive GC**: Force resource unloading and garbage collecting on every scene trasition, may reduce memory usage but slow down loading.
  + **Unlock All Modes**: Auto unlock Steel Soul mode and Godseeker mode.

All features can be toggled in-game.

## Configuration

- `features` (`Object`): Whether to enable specified features.
- `fastSuperDashSpeedMultiplier` (`Float`): Fast Super Dash speed multiplier. Ranges from `1` to `2`, defaults to `1.5`.
- `gpzEnterType` (`Bool`): Name the enter type Grey Prince use. `false` for long enter, `true` for short enter.
- `lagTime` (`Integer`): Lag time span in millisecond. Note that setting this to `0` does not mean zero lag. Ranges from `0` to `1000`, defaults to `50`.
- `lifebloodAmount` (`Integer`): The amount of lifeblood to be added. Ranges from `0` to `35`, defaults to `5`.
- `soulAmount` (`Integer`): The amount of soul to be added. Ranges from `0` to `198`, defaults to `99`.

## Statistics

![Repobeats analytics image](https://repobeats.axiom.co/api/embed/65e526723e20438fd78f8e117dee0a55cca44715.svg)
