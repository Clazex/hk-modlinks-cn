# DisableLowHealthVignette Hollow Knight Mod

This mod disables the vignette (black stuff around the screen) that appears when you are at low health (1 hp or 1 mask).