# [Already Enough PlayMaker](https://github.com/Clazex/HollowKnight.AlreadyEnoughPlayMaker)

A Hollow Knight optimization mod for PlayMaker FSMs.

Compatible with `Hollow Knight` 1.5.

## Contributing

1. Clone the repository
2. Set environment variable `HKRefs` to your `Managed` folder in HK installation
