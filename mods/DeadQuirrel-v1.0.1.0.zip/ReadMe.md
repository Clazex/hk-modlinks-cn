# Dead Quirrel

He's dead. Stop being in denial. Now featuring support for whether or not he has a mask.

Thanks to Failed Vessel for the idea and sprites.

## Dependencies
- Satchel
