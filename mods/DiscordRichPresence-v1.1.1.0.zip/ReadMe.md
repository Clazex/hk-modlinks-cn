HOLLOW KNIGHT DISCORD RPC MOD
[Made by KaanGaming#7447]

A Hollow Knight mod that enables detailed game status in your Discord profile.

You must have Discord installed in your computer, which can be done by scrolling all the way down in
servers list, then clicking the button that looks like a download button. Once the file downloads,
install Discord.
After that, you're ready to go!
(MUST NOT RUN DISCORD IN ADMINISTRATOR MODE)

If the mod fails, check the Plugins folder (located inside hollow_knight_Data/Plugins), check if
either x86 or x86_64 has discord game sdk files. If not, follow this guide:

https://kaangaming.github.io/HollowKnightDRPC/guide/Guide.html



Ping the creator if you have problems with the mod.