# Abskoth - an Absrad fight mod

Installing this mod will allow Markoth to spawn in the Absolute Radiance fight. By default, two will spawn. Mod settings can be changed to allow for 1-4 Markoths to spawn in the fight, as well as to remove Markoth's nails from spawning. Markoth will follow you through each phase of the fight.