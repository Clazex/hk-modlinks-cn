# [Charm Preset](https://github.com/Clazex/HollowKnight.CharmPreset)

A Hollow Knight mod that allows saving and loading charm presets.

Compatible with `Hollow Knight` 1.5.

## Contributing

1. Clone the repository
2. Set environment variable `HKRefs` to your `Managed` folder in HK installation
