# Dreamer Shard Rando

An add-on for the Randomizer 4 mod of the game Hollow Knight.

Adds a customizable amount of Dreamer Shards, which replace the Dreamers found in the original game.
Both total amount amount placed, and amount required to open the black egg are customizable.

Dependencies:
- Randomizer 4
- RandomizerCore
- MenuChanger
- ItemChanger

Integrations:
- ConnectionMetadataInjector
- RandoSettingsManager

Made by Toboter

Huge thanks to homothety, Flibber and BadMagic for their assistence
