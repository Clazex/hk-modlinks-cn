﻿# TwisterIndicator

A Hollow Knight mod that adds gray tint to spell twister spells
