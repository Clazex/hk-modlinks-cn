# Aspy Companion

Replaces Grimmchild with Ayu_Draws' Aspy OC.
Her Twitter: https://twitter.com/soff_doll?s=20
